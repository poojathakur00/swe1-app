[![Build Status](https://app.travis-ci.com/poojathakur00/swe1-app.svg?token=mfgmm8RRkgxGVCqTf2gG&branch=master)](https://app.travis-ci.com/poojathakur00/swe1-app)


[![Coverage Status](https://coveralls.io/repos/github/poojathakur00/swe1-app/badge.svg)](https://coveralls.io/github/poojathakur00/swe1-app)



Application URLS
-------------------------------------

http://django-env5.eba-5nua2zsy.us-west-1.elasticbeanstalk.com/polls












